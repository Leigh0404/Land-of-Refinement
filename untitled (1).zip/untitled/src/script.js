const questions = [
  {
    question: "What is the process of heat transfer through direct contact?",
    choices: ["Conduction", "Convection", "Radiation"],
    correct: "Conduction",
  },
  {
    question: "Which method of heat transfer does not require a medium?",
    choices: ["Conduction", "Convection", "Radiation"],
    correct: "Radiation",
  },
];

let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft = 10;

const startScreen = document.getElementById("start-screen");
const quizSection = document.getElementById("quiz-section");
const questionTitle = document.getElementById("question-title");
const choicesContainer = document.getElementById("choices-container");
const progressBar = document.getElementById("progress-bar");
const nextBtn = document.getElementById("next-btn");
const endScreen = document.getElementById("end-screen");
const finalScore = document.getElementById("final-score");
const timeDisplay = document.getElementById("time-left");
const teacherEdit = document.getElementById("teacher-edit");
const quizEditor = document.getElementById("quiz-editor");
const saveQuizBtn = document.getElementById("save-quiz");

// Sound effects
const correctSound = new Audio("correct.mp3");
const wrongSound = new Audio("wrong.mp3");
const endSound = new Audio("end.mp3");

// Start Quiz
document.getElementById("start-btn").addEventListener("click", startQuiz);

function startQuiz() {
  startScreen.style.display = "none";
  quizSection.style.display = "block";
  currentQuestionIndex = 0;
  score = 0;
  showQuestion();
}

function showQuestion() {
  const currentQuestion = questions[currentQuestionIndex];
  questionTitle.textContent = currentQuestion.question;
  choicesContainer.innerHTML = "";

  currentQuestion.choices.forEach((choice) => {
    const button = document.createElement("button");
    button.textContent = choice;
    button.classList.add("choice-btn");
    button.addEventListener("click", () => checkAnswer(choice));
    choicesContainer.appendChild(button);
  });

  progressBar.style.width = `${((currentQuestionIndex + 1) / questions.length) * 100}%`;

  resetTimer();
}

function checkAnswer(selectedChoice) {
  clearInterval(timer);
  const currentQuestion = questions[currentQuestionIndex];
  const buttons = document.querySelectorAll(".choice-btn");

  buttons.forEach((button) => {
    button.disabled = true;
    if (button.textContent === currentQuestion.correct) {
      button.classList.add("correct");
    } else {
      button.classList.add("wrong");
    }
  });

  if (selectedChoice === currentQuestion.correct) {
    correctSound.play();
    score++;
  } else {
    wrongSound.play();
  }

  nextBtn.style.display = "block";
}

nextBtn.addEventListener("click", () => {
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    showQuestion();
    nextBtn.style.display = "none";
  } else {
    showResults();
  }
});

function showResults() {
  quizSection.style.display = "none";
  endScreen.style.display = "block";
  finalScore.textContent = `You scored ${score} out of ${questions.length}!`;
  endSound.play();
}

// Timer Functions
function resetTimer() {
  clearInterval(timer);
  timeLeft = 10;
  timeDisplay.textContent = timeLeft;
  timer = setInterval(() => {
    timeLeft--;
    timeDisplay.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timer);
      checkAnswer(null);
    }
  }, 1000);
}

// Teacher Edit Mode
document.getElementById("save-quiz").addEventListener("click", () => {
  try {
    const editedQuestions = JSON.parse(quizEditor.value);
    questions.length = 0;
    editedQuestions.forEach((q) => questions.push(q));
    alert("Quiz updated successfully!");
  } catch (error) {
    alert("Invalid JSON format!");
  }
});

// Simulate teacher mode
const isTeacher = true; // Change this to false for students
if (isTeacher) {
  teacherEdit.style.display = "block";
  quizEditor.value = JSON.stringify(questions, null, 2);
}
